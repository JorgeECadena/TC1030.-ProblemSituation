#include ".\Episode.h"

/*
* Default constructor, sets every attribute as a NULL value
*/
Episode :: Episode() : id(NULL), name(NULL), lenght(Null), genre(NULL),number(NULL), season(NULL)  {

}

/*
* Parameterized constructor, receives int id, string name, float length, 
* string genre to set the class attributes
*/
Episode :: Episode(int id, std::string name, float length, std::string genre, unsigned short number, unsigned short season) :
id (id), name(name), lenght(length), genre(genre),number(number), season(season),  {

}

/*
* Returns class int id
*/
unsigned short Episode :: getNumber(void) {
    return number;
}

/*
* Returns class string name
*/
unsigned short Episode :: getSeason(void) {
    return season;
}


/*
* Set the id attribute value to the given int value
*/
void Episode :: setNumber(unsigned short number) {
    this -> number = number;
}

/*
* Set the name attribute value to the given string value
*/
void Episode :: setSeason(unsigned short season) {
    this -> season = season;
}
