#include ".\Movie.h"
#include ".\Video.h"

/*
* Default constructor, sets every attribute as a NULL value
*/
Movie :: Movie() : id(NULL), name(NULL), length(NULL), votes(NULL), gendre(gendre) {

}

/*
* Parameterized constructor, receives int id, string name, float length, 
* string votes to set the class attributes
*/
Movie :: Movie(int id, std::string name, float length, std::string votes) :
id(id), name(name), length(length), votes(votes) {

}

/*
* Returns class int id
*/
int Movie :: getVotes(void) {
    return votes;
}

/*
* Returns class string name
*/
std::string Video :: getName(void) {
    return name;
}

/*
* Returns class float length
*/
float Video :: getLength(void) {
    return length;
}

/*
* Returns class string genre
*/
std::string Video :: getGenre(void) {
    return genre;
}

/*
* Set the id attribute value to the given int value
*/
void Video :: setId(int id) {
    this -> id = id;
}

/*
* Set the name attribute value to the given string value
*/
void Video :: setName(std::string name) {
    this -> name = name;
}

/*
* Set the length attribute value to the given float value 
*/
void Video :: setLength(float length) {
    this -> length = length;
}

/*
* Set the genre attribute value to the given string value
*/
void Video :: setGenre(std::string genre) {
    this -> genre = genre;
}

/*
* Virtual method doesn't do anything on the father class
*/
void Video :: getRating(void) {

}