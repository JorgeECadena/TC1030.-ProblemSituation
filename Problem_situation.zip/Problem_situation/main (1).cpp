#include <iostream>
#include ".\Video.h"
#include ".\Movie.h"

int main() {

    return 0;
}