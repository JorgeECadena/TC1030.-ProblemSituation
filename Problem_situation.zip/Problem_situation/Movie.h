#pragma once

#include "Video.h"
#include <iostream>
#include <string>

using namespace std;

class Movie {
    public:
        // Constructors
        Movie();    // Default constructor
        Movie(int id, string name, float length, string genre, int votes);    // Parameterized constructor

        //Destructor
         ~Movie();

        // Getters
        int getVotes(void);
        void getRating(void);
        
        // Setters
        void setVotes(int votes);


       // void addVote(unsigned short value) override{

       // }

        


    private:
        // Define class attributes
        int votes;
};