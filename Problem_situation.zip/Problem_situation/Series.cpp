#include ".\Series.h"

/*
* Default constructor, sets every attribute as a NULL value
*/
Series :: Series() : id(NULL), name(NULL), length(NULL), genere(NULL), votes(NULL),  {

}

/*
* Parameterized constructor, receives int id, string name, float length, 
* string genre to set the class attributes
*/
Series :: Series(int id, std::string name, float length, std::string genre, int votes, vector episodes) :
id(id), name(name), length(length), genre(genre), votes(votes, episode(episode)) {

}

/*
* Returns class int id
*/
int Series :: getVotes(void) {
    return votes;
}

/*
* Returns class string name
*/
vector Series :: getEpisodes(void) {
    return episode;
}


/*
* Set the id attribute value to the given int value
*/
void Series :: setVotes(int votes) {
    this -> votes = votes;
}

/*
* Set the name attribute value to the given string value
*/
void Series :: setEpisodes(vector episodes) {
    this -> episodes = episodes;
}
