#pragma once

#include "Video.h"
#include <iostream>
#include <string>

class Series {
    public:
        // Constructors
        Series();    // Default constructor
        Series(int id, std::string name, float length, int votes, std::vector episodes);    // Parameterized constructor

        //Destructor
         ~Series();

        // Getters
        int getVotes(void);
        

        vector<Episode*> Episode;
        
        // Setters
        void setVotes(int votes);
        vector setEpisodes(vector getEpisodes);

        void getRating(void);

        void addVote(unsigned short value);

        


    private:
        // Define class attributes
        int votes;
        std::vector<std::Episode> Episode; 
};