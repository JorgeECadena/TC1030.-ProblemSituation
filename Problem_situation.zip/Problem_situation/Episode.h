#pragma once

#include "Video.h"
#include <iostream>
#include <string>

class Episode {
    public:
        // Constructors
        Episode();    // Default constructor
        Episode(int id, std::string name, float lenght, std::string genre, unsigned short number, unsigned short season);    // Parameterized constructor

        //Destructor
         ~Episode();

        // Getters
        unsigned short getNumber(void);
        unsigned short getSeason(void);
        
        // Setters
        void setNumber(unsigned short number);
        void setSeason(unsigned short season);


        


    private:
        // Define class attributes
        unsigned short number;
        unsigned short season;
    
};